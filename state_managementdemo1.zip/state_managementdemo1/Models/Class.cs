﻿namespace state_managementdemo1.Models
{
    public class Class
    {
        public int Id { get; set; }

        public string name { get; set; }

        public string email { get; set; }
    }
}
